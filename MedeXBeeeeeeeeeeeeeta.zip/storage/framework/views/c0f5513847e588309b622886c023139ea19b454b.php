

<?php $__env->startSection('title', 'Usuaios'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
<div class="row justify-content-md-center">
    <?php $__currentLoopData = $Users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $User): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-sm-3">
    <div class="card">
      <div class="card-body">
        PERSONAL<br>
        <?php echo e($User->name); ?><br>
        <!--<?php echo e($User->role); ?><br-->
        <?php echo e($User->email); ?>

      </div>
    </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appComun', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Usuario\Desktop\MedeX\resources\views/auth/allUsers.blade.php ENDPATH**/ ?>