

<?php $__env->startSection('title', 'Solicitud'); ?>

<?php $__env->startSection('content'); ?>

<table  width=100%>  <!-- Tabla vacia de separación -->
    <tr>
        <td><br/>
        </td>
    </tr>
</table>

<table  width=100%>  <!-- Códigos QR y firma -->
    <tr>
        <td width=20%>       
            
        </td>
        <td>
            <div class="col">
                <img class="mx-1 my-1" src="data:image/svg+xml;base64, <?php echo e(base64_encode($valor)); ?>"><br>
                <FONT SIZE=+1.2>ID: <?php echo e($id); ?><br>Equipo: <?php echo e($NomEquipo); ?><br>No. de serie: <?php echo e($NumSerie); ?></FONT>
            </div>
        </td>
        <br>
        <td>
            <div class="col">
                <img class="mx-1 my-1" src="data:image/svg+xml;base64, <?php echo e(base64_encode($valor)); ?>"><br>
                <FONT SIZE=+1.2>ID: <?php echo e($id); ?><br>Equipo: <?php echo e($NomEquipo); ?><br>No. de serie: <?php echo e($NumSerie); ?></FONT>
            </div>
        </td>
        <td width=25%>
        </td>
    </tr>
</table>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.Doc', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Usuario\Desktop\MedeX\resources\views/Formatos/QR.blade.php ENDPATH**/ ?>