
<?php $__env->startSection('title', 'Solicitud MC'); ?>

<?php $__env->startSection('content'); ?>

	<form class="form-group" method="POST" action="/Solicitud" enctype="multipart/form-data">
		<?php echo csrf_field(); ?>
		<div class="container-sm">
		<div class="form-group">
		
            <!-- 
			<label for="">ID</label>
			<input type="text" name="id" class="form-control">-->
			 

			<label for="">Código</label>
			<input type="string" name="ID_inv" class="form-control">
			<label for="">Descripción del fallo</label>
			<input type="longText" name="Descripcion_del_fallo" class="form-control">
			<label for="">Observaciones</label>
			<input type="longText" name="Observaciones" class="form-control">
			<!--<label for="">Fecha</label>
			<input type="string" name="Fecha" class="form-control">-->
			
		</div>

		<!-- <a type="submit" class="btn btn-secondary" href="<?php echo e(route('descargarPDF')); ?>" role="button">FORMATO PDF</a> -->

                
				<button type="submit" class="btn btn-primary">Guardar</button>
                                      
        </div>

	</form>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.appComun', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Enrique Garcia Vidal\Desktop\MedeX\resources\views/Formatos/SolicitudMC.blade.php ENDPATH**/ ?>