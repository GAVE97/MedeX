

<?php $__env->startSection('title', 'Reportes'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">    
    <div class="row">
        <?php $__currentLoopData = $Reportes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Reporte): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-3 col-md-5 col-sm-6 col-xs-6 mt-4" >
            <div class="card">
                <h5 class="card-header">Reporte</h5>
                <div class="card-body">
                    <h5 class="card-title">Nombre: <?php echo e($Reporte->ID_inv); ?></h5>

                    <p class="card-text"> Servicio hecho por: <?php echo e($Reporte->servDoneBy); ?><br>
                                          Acciones: <?php echo e($Reporte->Acciones); ?><br>
                                          Observaciones: <?php echo e($Reporte->Observaciones); ?>

                    </p>
                    
                    <a href="/Reportes/<?php echo e($Reporte->id); ?>" class="btn btn-primary">Ir al formato</a>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
    </div>
    </div>   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appComun', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Enrique Garcia Vidal\Desktop\MedeX\resources\views/Formatos/Reportes.blade.php ENDPATH**/ ?>