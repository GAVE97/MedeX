

<?php $__env->startSection('title', 'Inventario'); ?>

<?php $__env->startSection('search'); ?>
<form action="<?php echo e(route('filtrarInventario')); ?>" class="form-inline my-2 my-lg-0" method="POST">
	<?php echo csrf_field(); ?>
  <input class="form-control mr-sm-2" name="valor" id="valor" type="search" placeholder="Filtrar por..." aria-label="Search" aling="center">
  <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Buscar</button>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">    
    <div class="row">
        <?php $__currentLoopData = $Equipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Equipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-3 col-md-5 col-sm-6 col-xs-6 mt-4" >
                <div class="card text center" style="width: 14rem;">
                    <img src="../imgInv/<?php echo e($Equipo->imagenEquipo); ?>" height="200" width="200" class="card-img-top" alt="Imagen no soportada por el navegador">
                    <div class="card-body">
                    <h5 class="card-title"><?php echo e($Equipo->Nombre); ?></h5>
                    
                    <p class="card-text"> Modelo: <?php echo e($Equipo->Modelo); ?><br>
                                          Fabricante: <?php echo e($Equipo->Marca); ?><br>
                                          Estatus: <?php echo e($Equipo->Estatus); ?><br>
                                          ID: <?php echo e($Equipo->ID_inventario); ?><br>
                                          Área: <?php echo e($Equipo->Area); ?><br>
                                          Ubicación: <?php echo e($Equipo->Ubicacion); ?>

                    </p>

                    <a href="/Equipos/<?php echo e($Equipo->ID_inventario); ?>" class="btn btn-primary">Ir al equipo</a>
                    </div>
                </div> 
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
    </div>
</div>   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appComun', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Enrique Garcia Vidal\Desktop\MedeX\resources\views/Equipo/Inventario.blade.php ENDPATH**/ ?>