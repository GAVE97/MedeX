

<?php $__env->startSection('title', 'Marcas'); ?>

<?php $__env->startSection('content'); ?>
<!-- INDICACIONES DE LA VISTA-->
<div class="container-sm alert alert-primary" role="alert">
  <h4 class="alert-heading">Marcas existentes</h4>
  <p>estas son las marcas de los equipos existentes.</p>
  <hr>
  <p class="mb-0">Sea cuidadoso con la información.</p>
</div>


<div class="container">    
    <div class="row">
        <?php $__currentLoopData = $Marcas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Marca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-3 col-md-5 col-sm-6 col-xs-6 mt-4" >
            <div class="card text center" style="width: 14rem;">
                            <!--Añadir logos o fotos de las marcas-->
                <img src="imagenesEmpresas/<?php echo e($Marca->imagenMarca); ?>" height="200" width="200" class="card-img-top" alt="Imagen no soportada por el navegador">
                <div class="card-body">
                <h5 class="card-title"><?php echo e($Marca->NombreMrk); ?></h5>
                
                <p class="card-text"> Numero: <?php echo e($Marca->No_tel); ?><br>
                                        Correo electrónico: <?php echo e($Marca->email); ?><br>
                                        Ubicación: <?php echo e($Marca->Ubicacion); ?>

                </p>

                <a href="/Marcas/<?php echo e($Marca->NombreMrk); ?>" class="btn btn-primary">Ver marca</a>
                </div>
            </div> 
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
    </div>
    </div>   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appComun', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Usuario\Desktop\MedeX\resources\views/Equipo/Marcas.blade.php ENDPATH**/ ?>