

<?php $__env->startSection('title', 'Equipo'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-around">
        <div class="col-2 text-center">
                <div class="card" style="width: 18rem;">
                    <img src="../imgInv/<?php echo e($Equipo->imagenEquipo); ?>"class="card-img-top"  alt="Imagen no soportada por el navegador">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($Equipo->Nombre); ?></h5>
                    </div>
                    
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item">ID: <?php echo e($Equipo->ID_inventario); ?></li>
                        <li class="list-group-item">Área: <?php echo e($Equipo->Area); ?></li>
                        <li class="list-group-item">Tipo: <?php echo e($Equipo->Tipo); ?></li>
                        <li class="list-group-item">Marca: <?php echo e($Equipo->Marca); ?></li>
                        <li class="list-group-item">Modelo: <?php echo e($Equipo->Modelo); ?></li>
                        <li class="list-group-item">No. serie: <?php echo e($Equipo->Num_de_serie); ?></li>
                        <li class="list-group-item">Ubicación: <?php echo e($Equipo->Ubicacion); ?></li>
                        <li class="list-group-item">Estatus operativo: <?php echo e($Equipo->Estatus); ?></li>
                        <li class="list-group-item">Vencimiento garantia: <?php echo e($Equipo->vencimientoGarantia); ?></li>
                        <li class="list-group-item">Alimentacion electrica: <?php echo e($Equipo->Consumo_electrico); ?></li>
                        <li class="list-group-item">Mantenimientos brindados por: <?php echo e($Equipo->Mnto); ?></li>
                        <!--li class="list-group-item">Porcentaje de uso: <?php echo e($Equipo->porcentUso); ?>%</li-->
                        <li class="list-group-item">Prioridad: <?php echo e($Equipo->prioridad); ?></li>
                        <li class="list-group-item">Último mantenimiento: <?php echo e($Equipo->ultimoMantenimiento); ?></li>
                    </ul>
                        <div class="card-body">
                            <a href="/Equipos/<?php echo e($Equipo->ID_inventario); ?>/edit" class="btn btn-outline-primary btn-lg btn-block" role="button">Editar</a>
                            <a class="btn btn-info btn-lg btn-block mt-2" role="button" href="<?php echo e(route('Solicitud.create')); ?>">Solicitar mantenimiento</a>
                            <form action="<?php echo e(route('qr')); ?>" class="form-group mt-2" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="slider-wrapper">
                                    <label class="mt-2"> Tamaños del código</label></br>
                                    <input class="mb-3" type="range" min="70" max="480" name="Tamano" step="1">
                                </div>
                                <input class="form-control mr-sm-2" name="valor" id="valor" type="hidden" value="<?php echo e($Equipo->ID_inventario); ?>">
                                <button class="btn btn-outline-success btn-lg btn-block my-2 my-sm-0" type="submit">Generar QR</button>
                            </form>
                            <form class="form-group mt-2" method="POST" action="/Equipos/<?php echo e($Equipo->ID_inventario); ?>" enctype="multipart/form-data">
                                <?php echo method_field('DELETE'); ?>
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-danger btn-lg btn-block">Eliminar</button>
                            </form>
                        </div>
                </div>
        </div>
        <div class="col-8 border" >
        <div class="justify-content-center"><h1>PPROXIMOS MANTENIMIENTOS</h1></div>
            <div class="row">
                <?php $__currentLoopData = $fechas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fecha): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-3 col-md-5 col-sm-6 col-xs-6 mt-4 ml-4 mr-4" >
                    <div class="card" style="width: 18rem;">
                        <img src="../imgInv/<?php echo e($Equipo->imagenEquipo); ?>" class="card-img-top"  alt="Imagen no soportada por el navegador">
                        <div class="card-body"> <h5 class="card-title"><?php echo e($Equipo->Nombre); ?></h5>
                        </div>
                        <div class="card-body"> <h3><?php echo e($fecha); ?></h3>
                        </div>
                        
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div> 
            <a class="nav-link" href="<?php echo e(route('navegacion')); ?>">Navegación</a>
        </div>
    </div>
</div>   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appComun', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Usuario\Desktop\MedeX\resources\views/Equipo/ShowEquipo.blade.php ENDPATH**/ ?>