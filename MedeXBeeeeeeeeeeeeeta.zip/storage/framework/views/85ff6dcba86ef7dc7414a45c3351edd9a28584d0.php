

<?php $__env->startSection('title', 'Marcas'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">    
    <div class="row">
        <div class="col-lg-3 col-md-5 col-sm-6 col-xs-6 mt-4" >
                <div class="card text center" style="width: 14rem;">
                             <!--Añadir logos o fotos de las marcas-->
                    <img src="../imagenesEmpresas/<?php echo e($Marca->imagenMarca); ?>" height="200" width="200" class="card-img-top" alt="Imagen no soportada por el navegador">
                    <div class="card-body">
                    <h5 class="card-title"><?php echo e($Marca->NombreMrk); ?></h5>
                    
                    <p class="card-text"> Numero: <?php echo e($Marca->No_tel); ?><br>
                                          Correo electrónico: <?php echo e($Marca->email); ?><br>
                                          Ubicación: <?php echo e($Marca->Ubicacion); ?>

                    </p>

                    <a href="/Marcas/<?php echo e($Marca->NombreMrk); ?>/edit" class="card-link">Editar</a>
                    <form class="form-group" method="POST" action="/Marcas/<?php echo e($Marca->NombreMrk); ?>" enctype="multipart/form-data">
                    <?php echo method_field('DELETE'); ?>
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-secondary">Eliminar</button>
                    </form>
                    </div>
                </div> 
        </div>
    </div>
    </div>   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appComun', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Usuario\Desktop\MedeX\resources\views/Equipo/showMarca.blade.php ENDPATH**/ ?>