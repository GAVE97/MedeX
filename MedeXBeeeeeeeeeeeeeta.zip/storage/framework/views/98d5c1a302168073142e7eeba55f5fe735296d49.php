
<?php $__env->startSection('titulo', 'Solicitud MC'); ?>

<?php $__env->startSection('content'); ?>

	<form class="form-group" method="POST" action="/Ingenieros" enctype="multipart/form-data">
		<?php echo csrf_field(); ?>
		<div class="container-sm">
		<div class="form-group">
			<label for="">ID</label>
			<input type="text" name="id" class="form-control">
			<label for="">Nombre</label>
			<input type="text" name="Nombre" class="form-control">
			<label for="">Área</label>
			<input type="text" name="Área" class="form-control">
			<label for="">Modelo</label>
			<input type="text" name="Modelo" class="form-control">
			<label for="">Código</label>
			<input type="text" name="Codigo" class="form-control">
			<label for="">Fecha</label>
			<input type="text" name="Fecha" class="form-control">
			<label for="">Descipción del fallo</label>
			<input type="text" name="Descipción del fallo" class="form-control">
			<label for="">Observaciones</label>
			<input type="text" name="Observaciones" class="form-control">
		</div>

			
			<button type="submit" class="btn btn-primary">Guardar</button>

		

                <div class="links">
                    <a class="btn btn-secondary" href="http://localhost/pdf/"  role="button">FORMATO PDF</a>
                   </div>                   
        </div>

	</form>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Enrique Garcia Vidal\Desktop\MedeX\resources\views/SolicitudMC.blade.php ENDPATH**/ ?>