
<?php $__env->startSection('title', 'Add Inventario'); ?>

<?php $__env->startSection('content'); ?>

    <!-- Formulario para agregar equipo -->
	<form class="form-group" method="POST" action="/Equipos" enctype="multipart/form-data">
		<?php echo csrf_field(); ?>
		
        <!-- Información del equipo-->
		<div class="container-sm" class="form-group">
            
            <div class="row">
            <div class="col"> 

                <label for="">Código</label>
                <input type="string" name="ID_inventario" class="form-control" placeholder="Número de identificación de inventario">

                <label for="">Nombre</label>
                <input type="string" name="Nombre" class="form-control" placeholder="Nombre del equipo">
                
                <label for="">Área</label>
                <input type="string" name="Area" class="form-control" placeholder="Área de asignada para el equipo">
                
                <label for="">Tipo de equipo</label>
                <input type="string" name="Tipo" class="form-control" placeholder="Tipo de equipo">

                <label for="">Descripción</label>
                <input type="string" name="Descripción" class="form-control" placeholder="Descripción del equipo" >

                <label for="">Fabricante</label>
                <input type="string" name="Fabricante" class="form-control" placeholder="Empresa que fabricó el equipo">
           
            </div>
            <div class="col">

                <label for="">Modelo</label>
                <input type="string" name="Modelo" class="form-control" placeholder="Modelo del equipo">

                <label for="">Número de serie</label>
                <input type="string" name="Num_de_serie" class="form-control" placeholder="Número de serie proporcionado por el fabricante">

                <label for=""> Ubicación </label>
                <input type="string" name="Ubicacion" class="form-control" placeholder="Ubicación física en el centro de atención sanitaria">

                <label for="">Estatus operativo</label>
                <input type="string" name="Estatus" class="form-control" placeholder="Activo/Inactivo">

                <label for="">Alimentación</label>
                <input type="string" name="Consumo_electrico" class="form-control" placeholder="Especificación de consumo eléctrico">

                <label for="">Requisitos</label>
                <input type="string" name="Requisitos" class="form-control" placeholder="Requisitos de funcionamiento y mantenimiento"> 
           
            </div>
            </div> 

        </div> 
		<!-- Guardado de imagen del equipo -->
        <div class="container-sm" class="form-group">
        <div align="center" class="col" > <br/>
			<label for="">Foto del equipo</label> <br/>
            <input type="file" name="imagenEquipo"> <br/> <br/>
            
			
            <button type="submit" class="btn btn-primary">Guardar</button>
	         
            </div>           
        </div>
        

	</form>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appComun', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Enrique Garcia Vidal\Desktop\MedeX\resources\views/Equipo/AddToInventario2.blade.php ENDPATH**/ ?>