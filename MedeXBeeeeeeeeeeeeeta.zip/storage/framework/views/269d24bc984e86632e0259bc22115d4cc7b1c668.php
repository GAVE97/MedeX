

<?php $__env->startSection('title', 'Empresas Mantenimiento'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">    
    <div class="row">
        <div class="col-lg-3 col-md-5 col-sm-6 col-xs-6 mt-4" >
                <div class="card text center" style="width: 14rem;">
                             <!--Añadir logos o fotos de las empresas de mantenimiento-->
                    <img src="../imagenesEmpresas/<?php echo e($Mnto->imagenMnto); ?>" height="200" width="200" class="card-img-top" alt="Imagen no soportada por el navegador">
                    <div class="card-body">
                    <h5 class="card-title"><?php echo e($Mnto->Nombre); ?></h5>
                    
                    <p class="card-text"> Numero: <?php echo e($Mnto->No_tel); ?><br>
                                          Correo electrónico: <?php echo e($Mnto->email); ?><br>
                                          Ubicación: <?php echo e($Mnto->Ubicacion); ?>

                    </p>

                    <a href="/Mantenimiento/<?php echo e($Mnto->NombreMnto); ?>/edit" class="btn btn-primary">Editar</a>
                    <form class="form-group" method="POST" action="/Mantenimiento/<?php echo e($Mnto->NombreMnto); ?>" enctype="multipart/form-data">
                    <?php echo method_field('DELETE'); ?>
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-secondary">Eliminar</button>
                    </form>
                    </div>
                </div> 
        </div>
    </div>
</div>   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appComun', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Usuario\Desktop\MedeX\resources\views/Equipo/showMnto.blade.php ENDPATH**/ ?>