

<?php $__env->startSection('title', 'Solicitud'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">  <!-- $Solicitud antes era $Solicitud MC-->
<h4>Reporte:</h4>
        <strong>algo va aqui.</strong><br>
        algo va aqui.<br>
        algo va aqui.<br>
        algo va aqui.
<table class="table table-striped">
    <thead>
        <tr>
        <th scope="col" colspan="2">DATOS DEL EQUIPO</th>
        </tr>
    </thead>
    <tbody>
        <tr>
        <th scope="row">ID Equipo</th>
        <td><?php echo e($Solicitud->ID_Inv); ?></td>
        </tr>
        <tr>
        <th scope="row">Nombre</th>
        <td><?php echo e($Solicitud->Nombre); ?></td>
        </tr>
        <tr>
        <th scope="row">Marca</th>
        <td>L<?php echo e($Solicitud->ID_Inv); ?></td>
        </tr>
    </tbody>
</table>
<img src="data:image/svg+xml;base64, <?php echo e(base64_encode($valor)); ?>">
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.Doc', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Enrique Garcia Vidal\Desktop\MedeX\resources\views/Formatos/pruebaF.blade.php ENDPATH**/ ?>