

<?php $__env->startSection('title', 'Equipo'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">    
        <div class="card" style="width: 18rem;">
        <img src="../imgInv/<?php echo e($Equipo->imagenEquipo); ?>"class="card-img-top"  alt="Imagen no soportada por el navegador">
        <div class="card-body">
            <h5 class="card-title"><?php echo e($Equipo->Nombre); ?></h5>
        </div>
        
        <ul class="list-group list-group-flush">
            <li class="list-group-item"><?php echo e($Equipo->Descripción); ?></li>
            <li class="list-group-item">ID: <?php echo e($Equipo->ID_inventario); ?></li>
            <li class="list-group-item">Área: <?php echo e($Equipo->Area); ?></li>
            <li class="list-group-item">Tipo: <?php echo e($Equipo->Tipo); ?></li>
            <li class="list-group-item">Fabricante: <?php echo e($Equipo->Fabricante); ?></li>
            <li class="list-group-item">Modelo: <?php echo e($Equipo->Modelo); ?></li>
            <li class="list-group-item">No. serie: <?php echo e($Equipo->Num_de_serie); ?></li>
            <li class="list-group-item">Ubicación: <?php echo e($Equipo->Ubicacion); ?></li>
            <li class="list-group-item">Estatus operativo: <?php echo e($Equipo->Estatus); ?></li>
            <li class="list-group-item">Consumo electrico: <?php echo e($Equipo->Consumo_electrico); ?></li>
            <li class="list-group-item">Requisitos: <?php echo e($Equipo->Requisitos); ?></li>
        </ul>
            <div class="card-body">
                <a href="/Equipos/<?php echo e($Equipo->ID_inventario); ?>/edit" class="card-link">Editar</a>
                <form class="form-group" method="POST" action="/Equipos/<?php echo e($Equipo->ID_inventario); ?>" enctype="multipart/form-data">
                    <?php echo method_field('DELETE'); ?>
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-secondary">Eliminar</button>
                </form>
            </div>
        </div>
</div>   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appComun', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Enrique Garcia Vidal\Desktop\MedeX\resources\views/Equipo/ShowEquipo.blade.php ENDPATH**/ ?>