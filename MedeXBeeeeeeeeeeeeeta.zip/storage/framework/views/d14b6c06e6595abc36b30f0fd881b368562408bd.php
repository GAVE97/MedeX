

<?php $__env->startSection('title', 'PDFPRUEBA'); ?>

<?php $__env->startSection('content'); ?>


<table>
    
    <tr >
          <td colspan="4">
          REPORTE DE FALLA
          </td>
    </tr>


    <tr>
          <td colspan="2">ID: <?php echo e($SolicitudMC->ID_inv); ?>

          </td>
          <td colspan="2">Fecha: <input type="datetime" name="fecha">
          </td>
    </tr>


    <tr>
          <td "16%"> Nombre del equípo: </td>
          
          <td "34%"> </td>

          <td "16%"> Modelo: </td>
          
          <td "34%"> <?php echo e($SolicitudMC->Modelo); ?> </td>
    </tr>


    <tr>
          
          <td "16%" >Área: </td>
          
          <td "34%"> <?php echo e($SolicitudMC->Area); ?> </td>

          <td "16%">Código: </td>
          
          <td "34%">
          </td>
    </tr>


    <tr>Descripción del fallo: 
          </td>
    </tr>


    <tr>
          <td colspan="4"><br />
          </td>
    </tr>

    </tr>


    <tr>
          <td colspan="4">REPORTE DE FALLA 
          </td>
    </tr>


    <tr>
          <td colspan="4"><br />
          </td>
    </tr>

</table>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.Doc', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Enrique Garcia Vidal\Desktop\MedeX\resources\views/invoice.blade.php ENDPATH**/ ?>