

<?php $__env->startSection('title', 'Empresas Mantenimiento'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">    
    <div class="row">
        <?php $__currentLoopData = $Mntos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Mnto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-3 col-md-5 col-sm-6 col-xs-6 mt-4" >
                <div class="card text center" style="width: 14rem;">
                             <!--Añadir logos o fotos de las empresas de mantenimiento-->
                    <img src="imagenesEmpresas/<?php echo e($Mnto->imagenMnto); ?>" height="200" width="200" class="card-img-top" alt="Imagen no soportada por el navegador">
                    <div class="card-body">
                    <h5 class="card-title"><?php echo e($Mnto->Nombre); ?></h5>
                    
                    <p class="card-text"> Numero: <?php echo e($Mnto->No_tel); ?><br>
                                          Correo electrónico: <?php echo e($Mnto->email); ?><br>
                                          Ubicación: <?php echo e($Mnto->Ubicacion); ?>

                    </p>

                    <a href="/Equipos/<?php echo e($Mnto->ID_inventario); ?>" class="btn btn-primary">Ir al equipo</a>
                    </div>
                </div> 
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
    </div>
</div>   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appComun', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Enrique Garcia Vidal\Desktop\MedeX\resources\views/Equipo/Mntos.blade.php ENDPATH**/ ?>