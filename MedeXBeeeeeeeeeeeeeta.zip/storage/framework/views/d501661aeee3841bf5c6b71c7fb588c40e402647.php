

<?php $__env->startSection('title', 'Solicitud'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">  <!-- $Solicitud antes era $Solicitud MC-->
    <div class="row">
        <div class="col text-left">
            <div><h4>Reporte:</h4>
            Fecah: <?php echo e($Solicitud->created_at); ?></div></br></br></br></br></br></br>
            <div> FIRMA:
            <img src="../public/firma.png" height="90px" width="200px" alt="FIRMA"></div>
        </div>
        <div class="col text-right">
            <img src="data:image/svg+xml;base64, <?php echo e(base64_encode($valor1)); ?>"><br>
            Código de la solicitud.
        </div>
    </div>
    <div class="row">
        <div class="col">
            <table class="table table-striped">
                <thead>
                    <tr>
                    <th scope="col" colspan="2">DATOS DEL EQUIPO</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                    <th scope="row">ID Equipo</th>
                    <td><?php echo e($Solicitud->ID_inv); ?></td>
                    </tr>
                    <tr>
                    <th scope="row">Nombre</th>
                    <td><?php echo e($Solicitud->Nombre); ?></td>
                    </tr>
                    <tr>
                    <th scope="row">Marca</th>
                    <td><?php echo e($Solicitud->Marca); ?></td>
                    <tr>
                    <th scope="row">Modelo</th>
                    <td><?php echo e($Solicitud->Modelo); ?></td>
                    </tr>
                    <tr>
                    <th scope="row">Numero de série</th>
                    <td><?php echo e($Solicitud->Num_de_serie); ?></td>
                    </tr>
                    <tr>
                    <th scope="row">Area</th>
                    <td><?php echo e($Solicitud->Area); ?></td>
                    </tr>
                    <tr>
                    <th scope="row">Tipo</th>
                    <td><?php echo e($Solicitud->Tipo); ?></td>
                    </tr>
                    <tr>
                    <th scope="row">Ubicación</th>
                    <td><?php echo e($Solicitud->Ubicacion); ?></td>
                    </tr>
                    <tr>
                    <th scope="row">Mantenimiento brindado por:</th>
                    <td><?php echo e($Solicitud->Mnto); ?></td>
                    </tr>
                </tbody>
            </table>
        </div>

        <div class="col text-right">
            <img class="" src="data:image/svg+xml;base64, <?php echo e(base64_encode($valor2)); ?>"><br>
            Código del equipo.
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.Doc', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Enrique Garcia Vidal\Desktop\MedeX\resources\views/Formatos/prueba.blade.php ENDPATH**/ ?>