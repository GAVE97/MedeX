@extends('layouts.appComun')
@section('title', 'Bitacoras')

@section('content')

@endsection